import { Component, OnInit } from '@angular/core';
import { Cart } from '../../cart';
import { CartService } from '../../cart.service';
import { ElectronicsService } from '../../electronics.service';

@Component({
  selector: 'app-electronics',
  templateUrl: './electronics.component.html',
  styleUrls: ['./electronics.component.css']
})
export class ElectronicsComponent implements OnInit {
  electronics: any;

  constructor(private es:ElectronicsService, private cartService:CartService) { }

  ngOnInit(): void {
    this.es.findProductByCategory().subscribe((data)=>{
      console.log(data);
      // alert(data);
      this.electronics=data;});

  }
  fnAddToCart(id:any, price:any)
  {
    // alert(id);
    if(localStorage.getItem('customer')==null)
    {
      console.log("NOt logged in.")
      return;
    }
    var str:any;
    str=localStorage.getItem('customer');
    var customer=JSON.parse(str);
    var customer_id=customer.id;
    var product_id=id;
    var pricee =  price;

    var cart:Cart=new Cart();
    cart.id=0;      //dummy
    cart.customer_id=customer_id;
    cart.product_id=product_id;
    console.log("sending the below cart object to rest api now:");
    console.log(cart);
    this.cartService.add2Cart(customer_id,product_id, price).subscribe((data)=>{
      console.log(data);
      alert('Id ' +id+ ' added to cart');
    });
  }

}
