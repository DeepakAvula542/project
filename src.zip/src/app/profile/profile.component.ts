import { Component, OnInit } from '@angular/core';
import { AbstractControl, FormBuilder, FormGroup  } from '@angular/forms';
import { CustomerService } from '../customer.service';
//import { CustomerService } from 'src/app/customer.service';

@Component({
  selector: 'app-profile',
  templateUrl: './profile.component.html',
  styleUrls: ['./profile.component.css']
})
export class ProfileComponent implements OnInit {

  profileForm: any;
  constructor(private fb:FormBuilder, private cs:CustomerService) {
    this.profileForm=this.fb.group({
      id:[''],
      firstName:[''],
      lastName:[''],
      password:[''],
      cpassword:[''],
      mobile:[''],
      email:[''],
       address:[''],
    },
 
  );
  }
    ngOnInit(): void {
    }
   update()
   {
     this.cs.modifyCustomer(this.profileForm.value).subscribe(data=>{console.log(data)
     if(data==1)
     {
       alert("Details Updated Successfully")
     }
    }
     )
   }
  }
