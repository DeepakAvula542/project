import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';

@Injectable({
  providedIn: 'root'
})
export class ClothingService {
  url:string='http://localhost:8080/product/category/clothing';

  constructor(private http:HttpClient) { }

  getAllClothings()
  {
    return this.http.get(this.url);
  }
  findProductByCategory()
  {
      return this.http.get(this.url);

  }
}
