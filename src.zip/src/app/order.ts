export class Order {
    id:number=0;
    product_id:number=0;
    product_name:string="";
}
