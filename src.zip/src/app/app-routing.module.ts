import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { HomeComponent } from './pages/home/home.component';
import { LogoutComponent } from './pages/logout/logout.component';
// import { HomeComponent } from './home/home.component';
import { BookComponent } from './pages/book/book.component';
import { CartComponent } from './pages/cart/cart.component';

import { LoginComponent } from './pages/login/login.component';
import { SignupComponent } from './pages/signup/signup.component';
import { ProductComponent } from './pages/product/product.component';
import { ElectronicsComponent } from './pages/electronics/electronics.component';
import { ClothingComponent } from './pages/clothing/clothing.component';
import { FooterComponent } from './pages/footer/footer.component';
import { SlideComponent } from './pages/slide/slide.component';
import { OrderplacedComponent } from './pages/orderplaced/orderplaced.component';
import { PaymentComponent } from './pages/payment/payment.component';
import { OrderComponent } from './pages/order/order.component';
import { ProfileComponent } from './profile/profile.component';

const routes: Routes = [
  {path:'login', component:LoginComponent},
  {path:'signup', component:SignupComponent},
  {path:'home', component:HomeComponent},
  {path:'books', component:BookComponent},
  {path:'product', component:ProductComponent},
  {path:'cart', component:CartComponent},
  {path:'logout', component:LogoutComponent},
  {path:'electronics', component:ElectronicsComponent},
  {path:'clothings', component:ClothingComponent},
  {path:'payment', component:PaymentComponent},
  {path:'footer', component:FooterComponent},
  {path:'slide', component:SlideComponent},
  {path:'orderplaced',component:OrderplacedComponent},
  {path:'order', component:OrderComponent},
  {path:'profile',component:ProfileComponent}
  // {path:'loginbutton', component:HomeComponent}


];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
