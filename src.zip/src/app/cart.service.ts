import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class CartService {
  url:string='http://localhost:8080/cart';
  constructor(private http:HttpClient) { }

  getCartItemsByCustomerId(id:any)
  {
    return this.http.get(this.url+"/customer/"+id);
  }

  add2Cart(cid:any, pid:any, pricee:any)
  {
    return this.http.post(this.url+"/"+cid+"/"+pid + "/"+ pricee,null);
  }

  modifyCart(cart:any)
  {
    return this.http.put(this.url,cart);
  }

  removeFromCart(id:any)
  {
    return this.http.delete(this.url+"/"+id);
  }
}
