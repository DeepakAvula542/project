package com.OnlineShopping.dao;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.ParseException;
import java.text.SimpleDateFormat;

import org.springframework.jdbc.core.RowMapper;
import org.springframework.stereotype.Component;

import com.OnlineShopping.entity.Order;

@Component
public class OrderRowMapper implements RowMapper<Order>
{

	@Override
	public Order mapRow(ResultSet rs, int rowNum) throws SQLException {
		SimpleDateFormat sdf=new SimpleDateFormat("yyyy-MM-dd");
		Order order=null;
			try {
				order=new Order(rs.getLong(1), sdf.parse(rs.getString(2)), rs.getLong(3), rs.getLong(4), rs.getLong(5));
			} catch (ParseException e) {
				order=null;
			}
		return order;
	}

}

