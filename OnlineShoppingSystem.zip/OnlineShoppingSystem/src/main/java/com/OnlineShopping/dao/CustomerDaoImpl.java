package com.OnlineShopping.dao;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Component;

import com.OnlineShopping.entity.Customer;

@Component
public class CustomerDaoImpl implements CustomerDao{
	
	@Autowired
	private JdbcTemplate jdbcTemplate;
	
	@Override
	public int create(Customer customer) {
	return jdbcTemplate.update("INSERT INTO CUSTOMER VALUES (?,?,?,?,?,?,?,?)", customer.getId(), customer.getFirstName(), customer.getLastName(), customer.getPassword(), customer.getMobile(), customer.getEmail(), "customer", customer.getAddress());
	
	}
	
	@Override
	public List<Customer> read() {
		return jdbcTemplate.query("SELECT * FROM CUSTOMER", new CustomerRowMapper());
	}
	
	@Override
	public Customer read(Long id) {
		return jdbcTemplate.queryForObject("SELECT * FROM CUSTOMER WHERE id=?", new CustomerRowMapper(), id);
	}
	
	@Override
	public int update(Customer customer) {
		return jdbcTemplate.update("UPDATE CUSTOMER SET firstName=?, lastName=?, password=?, mobile=?, email=?,address=? WHERE id=?", customer.getFirstName(), customer.getLastName(), customer.getPassword(),customer.getMobile(), customer.getEmail(), customer.getAddress(),customer.getId());
	}
	
	@Override
	public int delete(Long id) {
		return jdbcTemplate.update("DELETE FROM CUSTOMER WHERE id=?",id);
	}
	
	

}
