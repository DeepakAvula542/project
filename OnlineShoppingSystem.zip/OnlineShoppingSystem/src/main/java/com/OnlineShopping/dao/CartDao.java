package com.OnlineShopping.dao;

import java.util.List;

import com.OnlineShopping.entity.Cart;

public interface CartDao {
	public int create(Cart cart);
	
	public List<Cart> read();
	
	public Cart read(Long id);
	
	public int update(Cart cart);
	
	public int delete(Long id);
	
	public List<Cart> cartByCustomerId(Long id);
	
	public List<Cart> readByCustomerId(Long id);
}

