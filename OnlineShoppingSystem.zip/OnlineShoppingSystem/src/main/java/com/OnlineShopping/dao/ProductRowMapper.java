package com.OnlineShopping.dao;


import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;

import com.OnlineShopping.entity.Product;


public class ProductRowMapper implements RowMapper<Product>
{

	@Override
	public Product mapRow(ResultSet rs, int rowNum) throws SQLException {
		return new Product(rs.getLong(1), rs.getString(2), rs.getString(3), rs.getDouble(4), rs.getBytes(5));
	}

}

