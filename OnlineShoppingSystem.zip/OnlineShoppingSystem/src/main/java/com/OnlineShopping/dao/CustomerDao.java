package com.OnlineShopping.dao;

import java.util.List;

import org.springframework.stereotype.Repository;

import com.OnlineShopping.entity.Customer;

@Repository

public interface CustomerDao {

	int create(Customer customer);

	List<Customer> read();

	Customer read(Long id);

	int update(Customer customer);

	int delete(Long id);
}
