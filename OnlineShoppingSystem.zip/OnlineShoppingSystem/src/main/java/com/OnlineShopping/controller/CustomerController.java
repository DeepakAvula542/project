package com.OnlineShopping.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.OnlineShopping.entity.Customer;
import com.OnlineShopping.service.CustomerService;


@RestController
@CrossOrigin({"http://localhost:4200","*"})
public class CustomerController {
		@Autowired
		private CustomerService cs;
		
		@PostMapping("/customer")
		public int signup(@RequestBody Customer customer)
		{
			
			return cs.create(customer);
		}
		
		@GetMapping("/customer")
		public List<Customer> getAllCustomers()
		{
			return cs.read();
		}
		
		@GetMapping("/customer/{id}")
		public Customer findCustomerById(@PathVariable Long id)
		{
			return cs.read(id);
		}
		
		@GetMapping("/customer/{id}/{password}")
		public Customer validateLogin(@PathVariable Long id, @PathVariable String password)
		{
			Customer customer=null;
			try {
			customer=cs.read(id);
			if(customer.getPassword().equals(password))
			{
				return customer;
			}else
			{
				return null;
			}
			}catch(Exception ex)
			{
				return null;
			}
		}
		
		@PutMapping("/customer")
		public int modifyCustomer(@RequestBody Customer customer)
		{
			return cs.update(customer);
		}
		
		@DeleteMapping("/customer/{id}")
		public int removeCustomer(@PathVariable Long id)
		{
			return cs.delete(id);
		}
	}

